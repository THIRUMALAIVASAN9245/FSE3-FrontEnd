﻿import { Component } from '@angular/core';

@Component({ templateUrl: 'manage-team-member-layout.component.html' })
export class ManageTeamMemberLayoutComponent { }