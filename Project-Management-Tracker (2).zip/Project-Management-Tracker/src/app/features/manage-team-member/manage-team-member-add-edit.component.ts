﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { UserService } from '@app/authentication/services/user.service';
import { MustMatch } from '@app/shared/helper/must-match.validator';
import { AlertService } from '@app/core/services/alert.service';
import { Guid } from 'guid-typescript';

@Component({ templateUrl: 'manage-team-member-add-edit.component.html' })
export class ManageTeamMemberAddEditComponent implements OnInit {
    form!: FormGroup;
    id?: number;
    title!: string;
    loading = false;
    submitting = false;
    submitted = false;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private userService: UserService,
        private alertService: AlertService
    ) {}

    ngOnInit() {
        this.id = this.route.snapshot.params['id'];
        
        this.form = this.formBuilder.group({
            memberName: ['', Validators.required],
            numberOfExp: [0, Validators.required],
            skillSets: ['', Validators.required],
            additionalInfo: ['', Validators.required],
            projectStartDate: ['', Validators.required],
            projectEndDate: ['', Validators.required],
            allocationPercentage: [0, Validators.required],
            role: ['', Validators.required]
        });

        this.title = 'Add User';
        if (this.id) {
            // edit mode
            this.title = 'Edit User';
            this.loading = true;
            this.userService.getTeamMemberById(this.id)
                .pipe(first())
                .subscribe(x => {
                    debugger;
                    this.form.patchValue(x);
                    this.loading = false;
                });
        }
    }

    // convenience getter for easy access to form fields
    get f() { return this.form.controls; }

    onSubmit() {
        this.submitted = true;

        // reset alerts on submit
        this.alertService.clear();

        // stop here if form is invalid
        if (this.form.invalid) {
            return;
        }

        this.submitting = true;
        this.saveUser()
            .pipe(first())
            .subscribe({
                next: () => {
                    this.alertService.success('User saved', { keepAfterRouteChange: true });
                    this.router.navigateByUrl('/manage-team-member');
                },
                error: error => {
                    this.alertService.error(error);
                    this.submitting = false;
                }
            })
    }

    private saveUser() {
        // create or update user based on id param
        return this.id
            ? this.userService.updateTeamMember(this.id!, this.form.value)
            : this.userService.createTeamMember(this.form.value);
    }
}