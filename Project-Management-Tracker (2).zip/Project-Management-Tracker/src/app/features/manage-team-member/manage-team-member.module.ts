import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { ManageTeamMemberRoutingModule } from './manage-team-member-routing.module';
import { ManageTeamMemberLayoutComponent } from './manage-team-member-layout.component';
import { ManageTeamMemberAddEditComponent } from './manage-team-member-add-edit.component';
import { ManageTeamMemberListComponent } from './manage-team-member-list.component';

@NgModule({
    imports: [
        CommonModule,
        ReactiveFormsModule,
        ManageTeamMemberRoutingModule
    ],
    declarations: [
        ManageTeamMemberLayoutComponent,
        ManageTeamMemberListComponent,
        ManageTeamMemberAddEditComponent
    ]
})
export class ManageTeamMemberModule { }