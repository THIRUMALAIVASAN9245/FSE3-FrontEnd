﻿import { Component, OnInit } from '@angular/core';
import { UserService } from '@app/authentication/services/user.service';
import { first } from 'rxjs/operators';


@Component({ templateUrl: 'manage-team-member-task-list.component.html' })
export class ManageTeamMemberTaskListComponent implements OnInit {
    users?: any[];

    constructor(private userService: UserService) { }

    ngOnInit() {
        debugger;
        this.userService.getTeamMemberTaskAll()
            .pipe(first())
            .subscribe(users => {
                debugger;
                this.users = users
            });
    }

    deleteUser(id: number) {
        const user = this.users!.find(x => x.id === id);
        user.isDeleting = true;
        this.userService.deleteTeamMemberTask(id)
            .pipe(first())
            .subscribe(() => this.users = this.users!.filter(x => x.id !== id));
    }
}