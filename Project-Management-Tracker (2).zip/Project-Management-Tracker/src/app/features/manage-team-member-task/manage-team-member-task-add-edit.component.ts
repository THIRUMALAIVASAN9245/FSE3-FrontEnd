﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { UserService } from '@app/authentication/services/user.service';
import { MustMatch } from '@app/shared/helper/must-match.validator';
import { AlertService } from '@app/core/services/alert.service';
import { Guid } from 'guid-typescript';
import { TeamMember } from '@app/core/models/team-member';

@Component({ templateUrl: 'manage-team-member-task-add-edit.component.html' })
export class ManageTeamMemberTaskAddEditComponent implements OnInit {
    form!: FormGroup;
    id?: number;
    title!: string;
    loading = false;
    submitting = false;
    submitted = false;
    dataList: Array<any> = [];
    teammemberInfo: any;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private userService: UserService,
        private alertService: AlertService
    ) { }

    ngOnInit() {
        debugger;
        this.userService.getTeamMemberListAll()
            .pipe(first())
            .subscribe(response => {
                debugger;
                this.dataList = response;
            });

        this.id = this.route.snapshot.params['id'];

        this.form = this.formBuilder.group({
            teamMemberName: ['', Validators.required],
            teamMemberId: ['', Validators.required],
            taskName: ['', Validators.required],
            deliverables: ['', Validators.required],
            taskStartDate: ['', Validators.required],
            taskEndDate: ['', Validators.required],
        });

        this.title = 'Add User';
        if (this.id) {
            debugger;
            // edit mode
            this.title = 'Edit User';
            this.loading = true;
            this.userService.getTeamMemberTaskById(this.id)
                .pipe(first())
                .subscribe(x => {
                    debugger;
                    this.form.patchValue(x);
                    this.loading = false;
                    this.getTeammemberInfo();
                });
        }
    }

    onChange() {
        debugger;
        this.getTeammemberInfo();
    }

    private getTeammemberInfo() {
        debugger;
        var ddd = this.f.teamMemberId.value;
        this.loading = true;
        this.userService.getTeamMemberById(+ddd)
            .pipe(first())
            .subscribe((x: TeamMember) => {
                debugger;
                this.teammemberInfo = x;
                this.f.teamMemberName.patchValue(x.memberName);
                this.loading = false;
            });
    }

    // convenience getter for easy access to form fields
    get f() { return this.form.controls; }

    onSubmit() {
        debugger;
        this.submitted = true;

        // reset alerts on submit
        this.alertService.clear();

        // stop here if form is invalid
        if (this.form.invalid) {
            return;
        }

        this.submitting = true;
        this.saveUser()
            .pipe(first())
            .subscribe({
                next: () => {
                    this.alertService.success('User saved', { keepAfterRouteChange: true });
                    this.router.navigateByUrl('/manage-team-member-task');
                },
                error: error => {
                    this.alertService.error(error);
                    this.submitting = false;
                }
            })
    }

    private saveUser() {
        // create or update user based on id param
        return this.id
            ? this.userService.updateTeamMemberTask(this.id!, this.form.value)
            : this.userService.createTeamMemberTask(this.form.value);
    }
}