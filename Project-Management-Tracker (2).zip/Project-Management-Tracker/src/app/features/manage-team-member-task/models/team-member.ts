﻿export interface TeamMemberList {
    id: number;
    memberName: string;
}