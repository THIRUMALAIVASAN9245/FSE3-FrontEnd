﻿import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { environment } from '@environments/environment';
import { User } from '@app/core/models/user';
import { TeamMember } from '@app/core/models/team-member';
import { TeamMemberList } from '@app/features/manage-team-member-task/models/team-member';

const baseUrl = `${environment.apiUrl}/users`;

@Injectable({ providedIn: 'root' })
export class UserService {
    constructor(private http: HttpClient) { }

    getAll() {
        return this.http.get<User[]>(baseUrl);
    }

    getById(id: number) {
        return this.http.get<User>(`${baseUrl}/${id}`);
    }

    create(params: any) {
        return this.http.post(baseUrl, params);
    }

    update(id: number, params: any) {
        return this.http.put(`${baseUrl}/${id}`, params);
    }

    delete(id: number) {
        return this.http.delete(`${baseUrl}/${id}`);
    }

    getTeamMemberAll() {
        return this.http.get<TeamMember[]>('http://localhost:3004/teamMembers?_sort=numberOfExp&_order=desc');
    }

    getTeamMemberById(id: number) {
        return this.http.get<TeamMember>('http://localhost:3004/teamMembers/'+id);
    }

    createTeamMember(params: any) {
        return this.http.post('http://localhost:3004/teamMembers', params);
    }

    updateTeamMember(id: number, params: any) {
        return this.http.put('http://localhost:3004/teamMembers/'+id, params);
    }

    deleteTeamMember(id: number) {
        return this.http.delete('http://localhost:3004/teamMembers/'+id);
    }
    
    getTeamMemberTaskAll(){
        return this.http.get<TeamMember[]>('http://localhost:3004/taskList');
    }

    getTeamMemberTaskById(id: number) {
        return this.http.get<TeamMember>('http://localhost:3004/taskList/'+id);
    }
    
    deleteTeamMemberTask(id: number) {
        return this.http.delete('http://localhost:3004/taskList/'+id);
    }

    getTeamMemberListAll() {
        return this.http.get<TeamMemberList[]>('http://localhost:3004/teamMembers?_sort=memberName&_order=asc');
    }

    createTeamMemberTask(params: any) {
        return this.http.post('http://localhost:3004/taskList', params);
    }

    updateTeamMemberTask(id: number, params: any) {
        return this.http.put('http://localhost:3004/taskList/'+id, params);
    }
}