﻿import { Component } from '@angular/core';
import { AuthenticationService } from '@app/core/services/authentication.service';
import { UserService } from '@app/shared/services/user.service';

@Component({ templateUrl: 'home.component.html' })
export class HomeComponent {
    loading = false;
    user: any;
    userFromApi?: any[];
    public data: any = [
        { name: "Adam" },
        { name: "Eve" },
        { name: "Lucifer" },
        { name: "Amenadiel" },
        { name: "Bob" },
        { name: "Sky" }
      ];
    
      public selectedValue: any;
      public searchValue: any;
      public filteredList: any = [];
    

    constructor(
        private userService: UserService,
        private authenticationService: AuthenticationService
    ) {
        this.user = <any>this.authenticationService.userValue;
    }

    ngOnInit() {
        debugger;
        this.filteredList = this.data;
        
        this.loading = true;
        this.userService.getTeamMemberTaskByTeamMenberId(this.user.id).subscribe(user => {
            this.loading = false;
            this.userFromApi = user;
        });
    }
}