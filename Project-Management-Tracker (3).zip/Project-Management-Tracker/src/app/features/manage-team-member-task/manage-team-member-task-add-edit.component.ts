﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AbstractControl, FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { UserService } from '@app/shared/services/user.service';
import { AlertService } from '@app/core/services/alert.service';
import { Guid } from 'guid-typescript';
import { TeamMember } from '@app/core/models/team-member';
import { DateValidators } from '@app/shared/helper/date.validators';

@Component({ templateUrl: 'manage-team-member-task-add-edit.component.html' })
export class ManageTeamMemberTaskAddEditComponent implements OnInit {
    form!: FormGroup;
    id?: number;
    title!: string;
    loading = false;
    submitting = false;
    submitted = false;
    dataList: Array<any> = [];
    teammemberInfo: any;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private userService: UserService,
        private alertService: AlertService
    ) { }

    ngOnInit() {
        debugger;
        this.userService.getTeamMemberListAll()
            .pipe(first())
            .subscribe(response => {
                debugger;
                this.dataList = response;
            });

        this.id = this.route.snapshot.params['id'];

        this.form = this.formBuilder.group({
            teamMemberName: [null, Validators.required],
            teamMemberId: [null, Validators.required],
            taskName: [null, Validators.required],
            deliverables: [null, Validators.required],
            taskStartDate: [null, Validators.required],
            taskEndDate: [null, Validators.required],
        }, {
            validator: Validators.compose([
                DateValidators.dateLessThan('taskStartDate', 'taskEndDate', { dateLessThan: true })
            ])
        });

        this.title = 'Add User';
        if (this.id) {
            debugger;
            // edit mode
            this.title = 'Edit User';
            this.loading = true;
            this.userService.getTeamMemberTaskById(this.id)
                .pipe(first())
                .subscribe(x => {
                    debugger;
                    this.form.patchValue(x);
                    this.loading = false;
                    this.getTeammemberInfo();
                });
        }
    }

    onChange() {
        debugger;
        this.getTeammemberInfo();
    }

    private getTeammemberInfo() {
        debugger;
        var ddd = this.f.teamMemberId.value;
        this.loading = true;
        this.userService.getTeamMemberById(+ddd)
            .pipe(first())
            .subscribe((x: TeamMember) => {
                debugger;
                this.teammemberInfo = x;
                this.f.teamMemberName.patchValue(x.memberName);
                this.loading = false;
            });
    }

    // convenience getter for easy access to form fields
    get f() { return this.form.controls; }

    onSubmit() {
        debugger;
        this.submitted = true;

        // reset alerts on submit
        this.alertService.clear();

        // stop here if form is invalid
        if (this.form.invalid) {
            return;
        }

        debugger;

        if (new Date(this.teammemberInfo.projectEndDate) < new Date(this.form.value.taskEndDate)) {
            this.alertService.error('Task End Date  should be less than Project End Date', { keepAfterRouteChange: false, autoClose: true });
            return;
        }

        if (new Date(this.teammemberInfo.projectStartDate) > new Date(this.form.value.taskStartDate)) {
            this.alertService.error('Task Start Date  should be greather than Project Start Date', { keepAfterRouteChange: false, autoClose: true });
            return;
        }

        this.submitting = true;
        this.saveUser()
            .pipe(first())
            .subscribe({
                next: () => {
                    this.alertService.success('User saved', { keepAfterRouteChange: true });
                    this.router.navigateByUrl('/manage-team-member-task');
                },
                error: error => {
                    this.alertService.error(error);
                    this.submitting = false;
                }
            })
    }

    private saveUser() {
        // create or update user based on id param
        return this.id
            ? this.userService.updateTeamMemberTask(this.id!, this.form.value)
            : this.userService.createTeamMemberTask(this.form.value);
    }
}

export class DateValidatorsNew {
    static dateLessThan(dateField1: string, dateField2: string, validatorField: { [key: string]: boolean }): ValidatorFn {
        return (c: AbstractControl | any): { [key: string]: boolean } | null => {
            const date1 = c.get(dateField1).value;
            const date2 = c.get(dateField2).value;
            if ((date1 !== "" && date2 !== "") && (date1 !== null && date2 !== null) && date1 > date2) {
                return validatorField;
            }
            return null;
        };
    }
}