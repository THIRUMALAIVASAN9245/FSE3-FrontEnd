﻿import { Component, OnInit } from '@angular/core';
import { UserService } from '@app/shared/services/user.service';
import { TeamMember } from '@app/core/models/team-member';
import { first } from 'rxjs/operators';


@Component({ templateUrl: 'manage-team-member-list.component.html' })
export class ManageTeamMemberListComponent implements OnInit {
    users?: TeamMember[] | any[];
    searchString: string = '';

    constructor(private userService: UserService) { }

    ngOnInit() {
        debugger;
        this.userService.getTeamMemberAll()
            .pipe(first())
            .subscribe(users => {
                debugger;
                this.users = users
            });
    }

    deleteUser(id: number) {
        const user = this.users!.find(x => x.id === id);
        this.userService.deleteTeamMember(id)
            .pipe(first())
            .subscribe(() => this.users = this.users!.filter(x => x.id !== id));
    }
}