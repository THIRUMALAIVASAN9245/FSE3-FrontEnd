﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { UserService } from '@app/shared/services/user.service';
import { AlertService } from '@app/core/services/alert.service';
import { DateValidators } from '@app/shared/helper/date.validators';
import { SkillSetValidator } from '@app/shared/helper/skill-set.validator';

@Component({ templateUrl: 'manage-team-member-add-edit.component.html' })
export class ManageTeamMemberAddEditComponent implements OnInit {
    form!: FormGroup;
    id?: number;
    title!: string;
    loading = false;
    submitting = false;
    submitted = false;
    cities = ['JavaScript', 'HTML', 'C#', 'SQL', 'DOTNET', 'ANGULAR', 'REACT', 'MongoDB', 'MySQL', 'Python', 'Power BI'];

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private userService: UserService,
        private alertService: AlertService
    ) { }

    ngOnInit() {
        this.id = this.route.snapshot.params['id'];

        this.form = this.formBuilder.group({
            memberName: [null, Validators.required],
            numberOfExp: [null, [Validators.required, Validators.max(65), Validators.min(4)]],
            additionalInfo: [null, Validators.required],
            projectStartDate: [null, [Validators.required]],
            projectEndDate: [null, Validators.required],
            allocationPercentage: [null, Validators.required],
            role: [null, Validators.required],
            skillSets: [null, Validators.required]
        }, {
            validator: Validators.compose([
                DateValidators.dateLessThan('projectStartDate', 'projectEndDate', { dateLessThan: true }),
                SkillSetValidator.minSkillsRequired('skillSets', 3, { requireCheckboxToBeChecked: true }),
            ])
        });

        this.projectEndDate.valueChanges.subscribe(value => {
            const date1 = new Date();
            const date2 = new Date(value);;
            if (date1 !== null && date2 !== null && date1 < date2) {
                this.allocationPercentage.patchValue(100);
            }

            if (date1 !== null && date2 !== null && date1 > date2) {
                this.allocationPercentage.patchValue(0);
            }

            this.form.updateValueAndValidity();
          });

        this.title = 'Add User';
        if (this.id) {
            // edit mode
            this.title = 'Edit User';
            this.loading = true;
            this.userService.getTeamMemberById(this.id)
                .pipe(first())
                .subscribe(x => {
                    debugger;
                    this.form.patchValue(x);
                    this.loading = false;
                });
        }
    }

    // convenience getter for easy access to form fields
    get f() { return this.form.controls; }

    get projectEndDate() {
        return this.form.get('projectEndDate') as FormControl;
    }

    get allocationPercentage() {
        return this.form.get('allocationPercentage') as FormControl;
    }

    onSubmit() {
        debugger;
        this.submitted = true;

        // reset alerts on submit
        this.alertService.clear();

        // stop here if form is invalid
        if (this.form.invalid) {
            return;
        }

        this.submitting = true;
        this.saveUser()
            .pipe(first())
            .subscribe({
                next: () => {
                    this.alertService.success('User saved', { keepAfterRouteChange: true });
                    this.router.navigateByUrl('/manage-team-member');
                },
                error: error => {
                    this.alertService.error(error);
                    this.submitting = false;
                }
            })
    }

    private saveUser() {
        // create or update user based on id param
        return this.id
            ? this.userService.updateTeamMember(this.id!, this.form.value)
            : this.userService.createTeamMember(this.form.value);
    }
}


