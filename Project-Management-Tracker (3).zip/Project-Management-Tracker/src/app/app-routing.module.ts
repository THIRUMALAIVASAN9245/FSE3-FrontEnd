import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './core/guard/auth.guard';
import { LoginComponent } from './authentication/login/login.component';
import { HomeComponent } from './shared/components/home/home.component';

const manageTeamMemberModule = () => import('./features/manage-team-member/manage-team-member.module').then(x => x.ManageTeamMemberModule);
const manageTeamMemberTaskModule = () => import('./features/manage-team-member-task/manage-team-member-task.module').then(x => x.ManageTeamMemberTaskModule);

const routes: Routes = [
    {
        path: '',
        component: HomeComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'login',
        component: LoginComponent
    },
    { path: 'manage-team-member', loadChildren: manageTeamMemberModule },
    { path: 'manage-team-member-task', loadChildren: manageTeamMemberTaskModule },
    { path: '**', redirectTo: '' }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
