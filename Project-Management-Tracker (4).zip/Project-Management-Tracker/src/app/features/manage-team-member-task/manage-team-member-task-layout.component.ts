﻿import { Component } from '@angular/core';

@Component({ templateUrl: 'manage-team-member-task-layout.component.html' })
export class ManageTeamMemberTaskLayoutComponent { }