
// // import { Pipe, PipeTransform } from '@angular/core';


// // @Pipe({
// //     name: 'searchName'
// // })
// // export class SearchNamePipe implements PipeTransform {
// //     transform(value: any, args?: any): any {
// //         debugger;
// //         if (!args) {
// //             return value;
// //         }
// //         return value.filter((value: any) => {
// //             return (value.memberName.toLocaleLowerCase().includes(args));
// //         });
// //     }
// // }

import { Pipe, PipeTransform, Injectable } from '@angular/core';

@Pipe({
    name: 'filter'
})

@Injectable()
export class SearchPipe implements PipeTransform {
    transform(items?: any[], field?: any, value?: any): any[] {

        console.log(value);
        if (!items) {
            return [];
        }
        if (!field || !value) {
            return items;
        }

        return items.filter(singleItem => singleItem[field].toLowerCase().includes(value.toLowerCase()));
    }
}