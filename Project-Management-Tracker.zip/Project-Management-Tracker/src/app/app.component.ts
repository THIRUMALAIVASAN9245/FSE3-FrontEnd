﻿import { Component } from '@angular/core';
import { Role } from './core/models/role';
import { User } from './core/models/user';
import { AuthenticationService } from './core/services/authentication.service';

@Component({ selector: 'app-root', templateUrl: 'app.component.html' })
export class AppComponent {
    user?: User | null;

    constructor(private authenticationService: AuthenticationService) {
        this.authenticationService.user.subscribe(x => this.user = x);
    }

    get isManager() {
        return this.user?.role === Role.Manager;
    }

    logout() {
        this.authenticationService.logout();
    }
}