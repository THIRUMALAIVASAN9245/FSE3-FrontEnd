﻿export enum Role {
    User = 'User',
    Manager = 'Manager'
}