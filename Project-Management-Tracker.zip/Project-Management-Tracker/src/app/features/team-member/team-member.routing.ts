import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '@app/core/guard/auth.guard';
import { Role } from '@app/core/models/role';
import { ViewTaskComponent } from './view-task/view-task.component';

const appRoutes: Routes = [
    {
        path: 'team-member',
        canActivate: [AuthGuard],
        data: { roles: [Role.Manager, Role.User] },
        children: [
            { path: '', redirectTo: '/view-task', pathMatch: 'full' },
            {
                path: "view-task",
                component: ViewTaskComponent
            }
        ]
    }
];

export const TeamMemberRouting = RouterModule.forRoot(appRoutes);