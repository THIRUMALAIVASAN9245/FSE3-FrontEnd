import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '@app/core/guard/auth.guard';
import { Role } from '@app/core/models/role';
import { ManageTeamMemberTaskComponent } from './manage-team-member-task/add-task-to-team-member.component';
import { ManageTeamMemberComponent } from './manage-team-member/manage-team-member.component';

const appRoutes: Routes = [
    {
        path: 'manager',
        canActivate: [AuthGuard],
        data: { roles: [Role.Manager] },
        children: [
            { path: '', redirectTo: '/manage-team-member', pathMatch: 'full' },
            {
                path: "manage-team-member",
                component: ManageTeamMemberComponent
            },
            {
                path: "manage-team-member-task",
                component: ManageTeamMemberTaskComponent
            }
        ]
    }
];

export const ManagerRouting = RouterModule.forRoot(appRoutes);