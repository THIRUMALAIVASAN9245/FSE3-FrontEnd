﻿import { Component, OnInit } from '@angular/core';
import { User } from '@app/core/models/user';
import { UserService } from '@app/authentication/services/user.service';
import { first } from 'rxjs/operators';

@Component({ templateUrl: 'manage-team-member.component.html' })
export class ManageTeamMemberComponent implements OnInit {
    loading = false;
    users: User[] = [];

    constructor(private userService: UserService) { }

    ngOnInit() {
        this.loading = true;
        this.userService.getAll().pipe(first()).subscribe(users => {
            this.loading = false;
            this.users = users;
        });
    }
}